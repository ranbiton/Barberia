package com.example.barberia.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.Navigation;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.barberia.Models.User;
import com.example.barberia.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private boolean isLoginInProgress = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
    }

    public void loginUser(String email, String password, View view) {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please fill out the entire form", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!isLoginInProgress) {
            isLoginInProgress = true;
            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    isLoginInProgress = false;
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            String userId = user.getUid();
                            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference().child("users").child(userId);
                            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.exists()) {
                                        boolean isAdmin = dataSnapshot.child("isAdmin").getValue(Boolean.class);
                                        if (isAdmin) {
                                            // User is an admin, navigate to admin screen
                                            Bundle bundle = new Bundle();
                                            bundle.putString("Email", email);
                                            bundle.putString("Password", password);
                                            Toast.makeText(MainActivity.this, "Successfully logged in as admin", Toast.LENGTH_SHORT).show();
                                            Navigation.findNavController(view).navigate(R.id.action_loginFragment_to_adminFragment, bundle);
                                        } else {
                                            // User is not an admin, navigate to user screen
                                            Bundle bundle = new Bundle();
                                            bundle.putString("Email", email);
                                            bundle.putString("Password", password);
                                            Toast.makeText(MainActivity.this, "Successfully logged in as user", Toast.LENGTH_SHORT).show();
                                            Navigation.findNavController(view).navigate(R.id.action_loginFragment_to_userFragment, bundle);
                                        }
                                    } else {
                                        // User data not found
                                        Toast.makeText(MainActivity.this, "User data not found", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                    // Handle database read error, if needed
                                }
                            });
                        }
                    } else {
                        // Log the exception if login fails
                        Exception exception = task.getException();
                        if (exception != null) {
                            exception.printStackTrace();
                        }
                        Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            Toast.makeText(MainActivity.this, "Please wait, login in progress...", Toast.LENGTH_SHORT).show();
        }
    }


    public void registerNewUser(String email, String password,String username, String phone,View view) {
        //first check that all fields are indeed filled.
        if (email.isEmpty() || password.isEmpty() || username.isEmpty() || phone.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please fill out the entire form", Toast.LENGTH_SHORT).show();
            return;
        }
        //check that the password length is compatible with googles wishes.
        if(password.length()<6){
            Toast.makeText(MainActivity.this, "Passwords must contain at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //Registration success, update UI with the signedin users information
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(MainActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                            Navigation.findNavController(view).navigate(R.id.action_registerFragment_to_loginFragment);
                            writeDataToDataBaseFirstTime(email, password, phone,  username);
                        } else {
                            // Log the exception if registration fails
                            Exception exception = task.getException();
                            if (exception != null) {
                                exception.printStackTrace();
                            }
                            //If registration fails, display a message to the user.
                            Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    public void writeDataToDataBaseFirstTime(String email, String password, String phone,
                                             String username) {
        FirebaseUser firebaseUser = mAuth.getCurrentUser();
        String userUID = firebaseUser.getUid();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("users").child(userUID);
        User user = new User(email, password, phone, username);
        myRef.setValue(user);
    }

    public void writeDataToDataBase(String email, String password, String phone) {
        FirebaseUser firebaseUser = mAuth.getCurrentUser();
        String userUID = firebaseUser.getUid();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("users").child(userUID);

        //Retrieve Data object from the database
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    //Retrieve Data object
                    User userData = dataSnapshot.getValue(User.class);
                    if (userData != null) {
                        //Extract userName from the Data object
                        String username = userData.getUserName();
                        //Create updated Data object with retrieved userName
                        User user = new User(email, password, phone, username);
                        //Update data in the database
                        myRef.setValue(user);
                    }
                } else {
                    //Handle the case where Data object does not exist
                    Toast.makeText(MainActivity.this, "User not found in database", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                //Handle error
                Toast.makeText(MainActivity.this, "Failed to retrieve data from database", Toast.LENGTH_SHORT).show();
            }
        });
    }










}